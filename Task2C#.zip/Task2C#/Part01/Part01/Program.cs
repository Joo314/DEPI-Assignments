﻿using System;

//// This program calculates the sum of two integers
//int x = 10; // First number
//int y = 20; // Second number

///* 
// * The following line adds x and y
// * and stores the result in sum
// */
//int sum = x + y;

//Console.WriteLine(sum); // Print the result
///////
////right code
//int x = 10;                // Correct: x is an integer
//int y = 20;                // Correct: y is an integer
//Console.WriteLine(x + y);  // Correct: Console is capitalized and y is defined

/////////////////
//pascal case       
//string FullName = "Youssef Abdelnaby";
//int Age = 22;
//double MonthlySalary = 15000.50;
//bool IsStudent = true;  

/////////////
//refrence type
//class Person
//{
//    public string Name;
//}

//class Program
//{
//    static void Main()
//    {
//        Person p1 = new Person();
//        p1.Name = "Ali";

//        Person p2 = p1; 
//        p2.Name = "Mohamed";

//        Console.WriteLine(p1.Name); //  Mohamed
//        Console.WriteLine(p2.Name); //  Mohamed
//    }
//}
//////////
// calculate the operations of two numbers
//int x = 15;
//int y = 4;

//Console.WriteLine("Sum: " + (x + y)) 19;
//Console.WriteLine("Difference: " + (x - y)) 11;
//Console.WriteLine("Product: " + (x * y)) 60;
//Console.WriteLine("Division: " + (x / y)) 3;
//Console.WriteLine("Remainder: " + (x % y)) 3;
//////////////////////////
///int a = 2, b = 7;
//Console.WriteLine(a % b) 2;
////////////////////////
//condition
//Console.Write("Enter a number: ");
//int num = int.Parse(Console.ReadLine());

//if (num > 10 && num % 2 == 0)
//{
//    Console.WriteLine("The number is greater than 10 and even.");
//}
//else
//{
//    Console.WriteLine("The number does not meet the conditions.");
//}
////////////////////////////
//casting
//Console.Write("Enter a double value: ");
//double d = double.Parse(Console.ReadLine());


//double implicitCast = d;


//int explicitCast = (int)d;

//Console.WriteLine("Implicit: " + implicitCast);
//Console.WriteLine("Explicit: " + explicitCast);
/////////////////////////////////// 
//parse
//Console.Write("Enter your age: ");
//string input = Console.ReadLine();

//try
//{
//    int age = int.Parse(input);
//    if (age > 0)
//        Console.WriteLine("Valid age: " + age);
//    else
//        Console.WriteLine("Age must be greater than 0.");
//}
//catch (FormatException)
//{
//    Console.WriteLine("Invalid input. Please enter a numeric value.");
//}
//prefix increment and postfix increment    
//int x = 5;
//int a = ++x; 
//Console.WriteLine("Prefix result: " + a + ", x = " + x);

//x = 5;
//int b = x++;
//Console.WriteLine("Postfix result: " + b + ", x = " + x);

