﻿using System;
using System.Linq;
using Bookstore_System;
using Bookstore_System.Contexts;
using Bookstore_System.Models;
using BookstoreSystem.Models;

namespace BookstoreSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            using var context = new BookstoreDbContext();

            context.Authors.Add(new Author { Name = "Naguib Mahfouz", Country = "Egypt" });
            context.Books.Add(new Book { Title = "Palace Walk", Price = 199.50m });
            context.SaveChanges();

            foreach (var book in context.Books.ToList())
                Console.WriteLine($"{book.Id} - {book.Title} - {book.Price}");
        }
    }
}