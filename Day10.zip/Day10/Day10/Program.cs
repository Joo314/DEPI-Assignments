﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Day10
{
    public class Employee : IComparable<Employee>, ICloneable
    {
        public string Name { get; set; }
        public double Salary { get; set; }

        public Employee(string name, double salary)
        {
            Name = name;
            Salary = salary;
        }

        public int CompareTo(Employee other)
        {
            return Salary.CompareTo(other.Salary);
        }

        public object Clone()
        {
            return new Employee(Name, Salary);
        }

        public override string ToString()
        {
            return $"{Name} - {Salary}";
        }
    }

    public class Manager : Employee, IComparable<Manager>
    {
        public int TeamSize { get; set; }

        public Manager(string name, double salary, int teamSize) : base(name, salary)
        {
            TeamSize = teamSize;
        }

        public int CompareTo(Manager other)
        {
            return Salary.CompareTo(other.Salary);
        }
    }

    public class SortingAlgorithm<T> where T : IComparable<T>
    {
        public void Sort(T[] array)
        {
            for (int i = 0; i < array.Length - 1; i++)
            {
                for (int j = 0; j < array.Length - i - 1; j++)
                {
                    if (array[j].CompareTo(array[j + 1]) > 0)
                    {
                        Swap(array, j, j + 1);
                    }
                }
            }
        }

        public static void Swap<TItem>(TItem[] array, int i, int j)
        {
            TItem temp = array[i];
            array[i] = array[j];
            array[j] = temp;
        }

        public static TValue GetDefault<TValue>()
        {
            return default(TValue);
        }
    }

    public class SortingAlgorithmCloneable<T> where T : ICloneable
    {
        public T[] CloneArray(T[] array)
        {
            T[] cloned = new T[array.Length];
            for (int i = 0; i < array.Length; i++)
            {
                cloned[i] = (T)array[i].Clone();
            }
            return cloned;
        }
    }

    public class SortingTwo<T>
    {
        public void Sort(T[] array, Comparison<T> comparer)
        {
            for (int i = 0; i < array.Length - 1; i++)
            {
                for (int j = 0; j < array.Length - i - 1; j++)
                {
                    if (comparer(array[j], array[j + 1]) > 0)
                    {
                        T temp = array[j];
                        array[j] = array[j + 1];
                        array[j + 1] = temp;
                    }
                }
            }
        }
    }

    public class Program
    {
        public static void Main(string[] args)
        {
            #region problem 1
            Employee[] employees1 =
            {
                new Employee("Ali", 5000),
                new Employee("Sara", 3000),
                new Employee("Omar", 7000)
            };
            SortingAlgorithm<Employee> sortingAlgorithm1 = new SortingAlgorithm<Employee>();
            sortingAlgorithm1.Sort(employees1);
            Console.WriteLine("Problem 1: Employees sorted by salary ascending");
            foreach (var e in employees1)
                Console.WriteLine(e);
            #endregion

            #region problem 2
            int[] numbers2 = { 5, 3, 8, 1, 9, 2 };
            SortingTwo<int> sortingTwo2 = new SortingTwo<int>();
            sortingTwo2.Sort(numbers2, (a, b) => b.CompareTo(a));
            Console.WriteLine("Problem 2: Integers sorted descending");
            foreach (var n in numbers2)
                Console.WriteLine(n);
            #endregion

            #region problem 3
            string[] words3 = { "banana", "kiwi", "apple", "fig", "watermelon" };
            SortingTwo<string> sortingTwo3 = new SortingTwo<string>();
            Comparison<string> lengthComparer = (a, b) => a.Length.CompareTo(b.Length);
            sortingTwo3.Sort(words3, lengthComparer);
            Console.WriteLine("Problem 3: Strings sorted by length ascending");
            foreach (var w in words3)
                Console.WriteLine(w);
            #endregion

            #region problem 4
            Manager[] managers4 =
            {
                new Manager("Hana", 9000, 5),
                new Manager("Youssef", 6000, 2),
                new Manager("Mona", 8000, 8)
            };
            SortingTwo<Manager> sortingTwo4 = new SortingTwo<Manager>();
            sortingTwo4.Sort(managers4, (a, b) => a.Salary.CompareTo(b.Salary));
            Console.WriteLine("Problem 4: Managers sorted by salary ascending");
            foreach (var m in managers4)
                Console.WriteLine(m);
            #endregion

            #region problem 5
            Employee[] employees5 =
            {
                new Employee("Ahmed", 4000),
                new Employee("Al", 4500),
                new Employee("Mohammed", 3500)
            };
            Func<Employee, Employee, bool> nameLengthComparer5 = (a, b) => a.Name.Length > b.Name.Length;
            for (int i = 0; i < employees5.Length - 1; i++)
            {
                for (int j = 0; j < employees5.Length - i - 1; j++)
                {
                    if (nameLengthComparer5(employees5[j], employees5[j + 1]))
                    {
                        Employee temp = employees5[j];
                        employees5[j] = employees5[j + 1];
                        employees5[j + 1] = temp;
                    }
                }
            }
            Console.WriteLine("Problem 5: Employees sorted by name length");
            foreach (var e in employees5)
                Console.WriteLine(e);
            #endregion

            #region problem 6
            int[] numbers6a = { 7, 2, 9, 4, 1 };
            Comparison<int> anonymousComparer6 = delegate (int a, int b)
            {
                return a.CompareTo(b);
            };
            SortingTwo<int> sortingTwo6a = new SortingTwo<int>();
            sortingTwo6a.Sort(numbers6a, anonymousComparer6);
            Console.WriteLine("Problem 6: Sorted ascending using anonymous method");
            foreach (var n in numbers6a)
                Console.WriteLine(n);

            int[] numbers6b = { 7, 2, 9, 4, 1 };
            Comparison<int> lambdaComparer6 = (a, b) => a.CompareTo(b);
            SortingTwo<int> sortingTwo6b = new SortingTwo<int>();
            sortingTwo6b.Sort(numbers6b, lambdaComparer6);
            Console.WriteLine("Problem 6: Sorted ascending using lambda expression");
            foreach (var n in numbers6b)
                Console.WriteLine(n);
            #endregion

            #region problem 7
            int[] numbers7 = { 10, 20, 30 };
            Console.WriteLine("Problem 7: Before swap");
            foreach (var n in numbers7)
                Console.WriteLine(n);
            SortingAlgorithm<int>.Swap(numbers7, 0, 2);
            Console.WriteLine("Problem 7: After swap");
            foreach (var n in numbers7)
                Console.WriteLine(n);
            #endregion

            #region problem 8
            Employee[] employees8 =
            {
                new Employee("Zaid", 5000),
                new Employee("Amir", 5000),
                new Employee("Bilal", 3000)
            };
            SortingTwo<Employee> sortingTwo8 = new SortingTwo<Employee>();
            sortingTwo8.Sort(employees8, (a, b) =>
            {
                int salaryComparison = a.Salary.CompareTo(b.Salary);
                if (salaryComparison != 0)
                    return salaryComparison;
                return string.Compare(a.Name, b.Name, StringComparison.Ordinal);
            });
            Console.WriteLine("Problem 8: Employees sorted by salary then name");
            foreach (var e in employees8)
                Console.WriteLine(e);
            #endregion

            #region problem 9
            int defaultInt9 = SortingAlgorithm<int>.GetDefault<int>();
            string defaultString9 = SortingAlgorithm<string>.GetDefault<string>();
            Console.WriteLine("Problem 9: default(int) = " + defaultInt9);
            Console.WriteLine("Problem 9: default(string) = " + (defaultString9 == null ? "null" : defaultString9));
            #endregion

            #region problem 10
            Employee[] employees10 =
            {
                new Employee("Salma", 4000),
                new Employee("Tariq", 6000)
            };
            SortingAlgorithmCloneable<Employee> cloneable10 = new SortingAlgorithmCloneable<Employee>();
            Employee[] clonedEmployees10 = cloneable10.CloneArray(employees10);
            SortingAlgorithm<Employee> sortingAlgorithm10 = new SortingAlgorithm<Employee>();
            sortingAlgorithm10.Sort(clonedEmployees10);
            Console.WriteLine("Problem 10: Cloned employees sorted by salary");
            foreach (var e in clonedEmployees10)
                Console.WriteLine(e);
            #endregion

            #region problem 11
            Func<string, string> toUpper11 = s => s.ToUpper();
            Func<string, string> reverse11 = s => new string(s.Reverse().ToArray());
            List<string> words11 = new List<string> { "hello", "world", "csharp" };
            List<string> upperResult11 = ApplyTransform(words11, toUpper11);
            List<string> reverseResult11 = ApplyTransform(words11, reverse11);
            Console.WriteLine("Problem 11: Uppercase transform");
            foreach (var w in upperResult11)
                Console.WriteLine(w);
            Console.WriteLine("Problem 11: Reverse transform");
            foreach (var w in reverseResult11)
                Console.WriteLine(w);
            #endregion

            #region problem 12
            Func<int, int, int> add12 = (a, b) => a + b;
            Func<int, int, int> subtract12 = (a, b) => a - b;
            Func<int, int, int> multiply12 = (a, b) => a * b;
            Func<int, int, int> divide12 = (a, b) => a / b;
            Console.WriteLine("Problem 12: Add = " + PerformOperation(6, 3, add12));
            Console.WriteLine("Problem 12: Subtract = " + PerformOperation(6, 3, subtract12));
            Console.WriteLine("Problem 12: Multiply = " + PerformOperation(6, 3, multiply12));
            Console.WriteLine("Problem 12: Divide = " + PerformOperation(6, 3, divide12));
            #endregion

            #region problem 13
            List<int> integers13 = new List<int> { 1, 2, 3, 4 };
            Func<int, string> intToString13 = i => i.ToString();
            List<string> stringResult13 = TransformList(integers13, intToString13);
            Console.WriteLine("Problem 13: Integers transformed to strings");
            foreach (var s in stringResult13)
                Console.WriteLine(s);
            #endregion

            #region problem 14
            Func<int, int> square14 = x => x * x;
            List<int> integers14 = new List<int> { 1, 2, 3, 4, 5 };
            List<int> squares14 = ApplyFunc(integers14, square14);
            Console.WriteLine("Problem 14: Squares");
            foreach (var s in squares14)
                Console.WriteLine(s);
            #endregion

            #region problem 15
            Action<string> printAction15 = s => Console.WriteLine(s);
            List<string> words15 = new List<string> { "apple", "banana", "cherry" };
            ApplyAction(words15, printAction15);
            #endregion

            #region problem 16
            Predicate<int> isEven16 = n => n % 2 == 0;
            List<int> integers16 = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8 };
            List<int> evenNumbers16 = FilterList(integers16, isEven16);
            Console.WriteLine("Problem 16: Even numbers");
            foreach (var n in evenNumbers16)
                Console.WriteLine(n);
            #endregion

            #region problem 17
            List<string> words17 = new List<string> { "apple", "banana", "avocado", "grape" };
            List<string> startsWithA17 = FilterStrings(words17, delegate (string s) { return s.StartsWith("a"); });
            Console.WriteLine("Problem 17: Words starting with 'a'");
            foreach (var w in startsWithA17)
                Console.WriteLine(w);
            #endregion

            #region problem 18
            Func<int, int, int> addOp18 = delegate (int a, int b) { return a + b; };
            Func<int, int, int> subtractOp18 = delegate (int a, int b) { return a - b; };
            Func<int, int, int> multiplyOp18 = delegate (int a, int b) { return a * b; };
            Console.WriteLine("Problem 18: Add = " + addOp18(10, 5));
            Console.WriteLine("Problem 18: Subtract = " + subtractOp18(10, 5));
            Console.WriteLine("Problem 18: Multiply = " + multiplyOp18(10, 5));
            #endregion

            #region problem 19
            List<string> words19 = new List<string> { "cat", "elephant", "dog", "tree", "bee" };
            List<string> longerThan3_19 = FilterStrings(words19, s => s.Length > 3);
            List<string> containsE19 = FilterStrings(words19, s => s.Contains("e"));
            Console.WriteLine("Problem 19: Length greater than 3");
            foreach (var w in longerThan3_19)
                Console.WriteLine(w);
            Console.WriteLine("Problem 19: Contains letter e");
            foreach (var w in containsE19)
                Console.WriteLine(w);
            #endregion

            #region problem 20
            Func<double, double, double> divide20 = (a, b) => a / b;
            Func<double, double, double> power20 = (a, b) => Math.Pow(a, b);
            Console.WriteLine("Problem 20: Divide = " + divide20(10, 4));
            Console.WriteLine("Problem 20: Power = " + power20(2, 5));
            #endregion
        }

        public static List<string> ApplyTransform(List<string> list, Func<string, string> transform)
        {
            List<string> result = new List<string>();
            foreach (var item in list)
                result.Add(transform(item));
            return result;
        }

        public static int PerformOperation(int a, int b, Func<int, int, int> operation)
        {
            return operation(a, b);
        }

        public static List<TResult> TransformList<T, TResult>(List<T> list, Func<T, TResult> transform)
        {
            List<TResult> result = new List<TResult>();
            foreach (var item in list)
                result.Add(transform(item));
            return result;
        }

        public static List<int> ApplyFunc(List<int> list, Func<int, int> func)
        {
            List<int> result = new List<int>();
            foreach (var item in list)
                result.Add(func(item));
            return result;
        }

        public static void ApplyAction(List<string> list, Action<string> action)
        {
            foreach (var item in list)
                action(item);
        }

        public static List<int> FilterList(List<int> list, Predicate<int> predicate)
        {
            List<int> result = new List<int>();
            foreach (var item in list)
                if (predicate(item))
                    result.Add(item);
            return result;
        }

        public static List<string> FilterStrings(List<string> list, Func<string, bool> condition)
        {
            List<string> result = new List<string>();
            foreach (var item in list)
                if (condition(item))
                    result.Add(item);
            return result;
        }
    }
}