﻿using System;

class DAY5
{
    static void Main()
    {
        // Problem 1
        
        int a1 = int.Parse(Console.ReadLine());
        int b1 = int.Parse(Console.ReadLine());
        try
        {
            int result1 = a1 / b1;
            Console.WriteLine(result1);
        }
        catch (DivideByZeroException)
        {
            Console.WriteLine("Cannot divide by zero");
        }
        finally
        {
            Console.WriteLine("Operation complete");
        }

        // Problem 2
        
        int x, y;
        while (true)
        {
            Console.Write("Enter X (positive): ");
            if (int.TryParse(Console.ReadLine(), out x) && x > 0) break;
            Console.WriteLine("Invalid input, try again");
        }
        while (true)
        {
            Console.Write("Enter Y (greater than 1): ");
            if (int.TryParse(Console.ReadLine(), out y) && y > 1) break;
            Console.WriteLine("Invalid input, try again");
        }
        Console.WriteLine($"X = {x}, Y = {y}");

        // Problem 3
       
        int? number = null;
        int value = number ?? 10;
        Console.WriteLine(value);

        if (number.HasValue)
            Console.WriteLine(number.Value);
        else
            Console.WriteLine("Number has no value");

        // Problem 4
       
        int[] arr4 = new int[5];
        for (int i = 0; i < 5; i++)
            arr4[i] = i + 1;

        try
        {
            Console.WriteLine(arr4[10]);
        }
        catch (IndexOutOfRangeException)
        {
            Console.WriteLine("Index is out of bounds");
        }

        // Problem 5
        
        int[,] arr5 = new int[3, 3];
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++)
            {
                Console.Write($"Enter value [{i},{j}]: ");
                arr5[i, j] = int.Parse(Console.ReadLine());
            }

        for (int i = 0; i < arr5.GetLength(0); i++)
        {
            int rowSum = 0;
            for (int j = 0; j < arr5.GetLength(1); j++)
                rowSum += arr5[i, j];
            Console.WriteLine($"Row {i} sum = {rowSum}");
        }

        for (int j = 0; j < arr5.GetLength(1); j++)
        {
            int colSum = 0;
            for (int i = 0; i < arr5.GetLength(0); i++)
                colSum += arr5[i, j];
            Console.WriteLine($"Column {j} sum = {colSum}");
        }

        // Problem 6
       
        int[][] jagged = new int[3][];
        for (int i = 0; i < 3; i++)
        {
            Console.Write($"Enter size of row {i}: ");
            int size = int.Parse(Console.ReadLine());
            jagged[i] = new int[size];
            for (int j = 0; j < size; j++)
            {
                Console.Write($"Enter value [{i}][{j}]: ");
                jagged[i][j] = int.Parse(Console.ReadLine());
            }
        }

        for (int i = 0; i < jagged.Length; i++)
        {
            for (int j = 0; j < jagged[i].Length; j++)
                Console.Write(jagged[i][j] + " ");
            Console.WriteLine();
        }

        // Problem 7
       
        string? name = null;
        Console.Write("Enter your name (or leave blank): ");
        string input7 = Console.ReadLine();
        if (!string.IsNullOrEmpty(input7))
            name = input7;

        Console.WriteLine(name!.ToUpper());

        // Problem 8
        Console.WriteLine("Problem 8");
        int num8 = 10;
        object boxed = num8;

        try
        {
            int unboxed = (int)boxed;
            Console.WriteLine(unboxed);

            double wrong = (double)boxed;
            Console.WriteLine(wrong);
        }
        catch (InvalidCastException)
        {
            Console.WriteLine("Invalid cast");
        }

        // Problem 9
        
        int a9 = 4, b9 = 5;
        int sum9 = a9 + b9;
        int product9 = a9 * b9;
        Console.WriteLine($"Sum = {sum9}, Product = {product9}");

        // Problem 10
        
        string text10 = "Hello";
        int times10 = 3;
        for (int i = 0; i < times10; i++)
            Console.WriteLine(text10);

        // Problem 11
       
        int[]? numbers11 = null;
        Console.WriteLine(numbers11?.Length);

        numbers11 = new int[] { 1, 2, 3 };
        Console.WriteLine(numbers11?.Length);

        // Problem 12
        
        Console.Write("Enter a day of the week: ");
        string day = Console.ReadLine();

        int dayNumber = day switch
        {
            "Monday" => 1,
            "Tuesday" => 2,
            "Wednesday" => 3,
            "Thursday" => 4,
            "Friday" => 5,
            "Saturday" => 6,
            "Sunday" => 7,
            _ => 0
        };

        Console.WriteLine(dayNumber);

        // Problem 13
        
        int[] values13 = { 1, 2, 3, 4 };
        int sum13 = 0;
        foreach (int n in values13)
            sum13 += n;
        Console.WriteLine(sum13);

        // Problem 14
       
        Console.Write("Enter a positive integer: ");
        int n14 = int.Parse(Console.ReadLine());

        for (int i = 1; i <= n14; i++)
            Console.Write(i + (i < n14 ? ", " : "\n"));

        // Problem 15
        
        Console.Write("Enter an integer: ");
        int n15 = int.Parse(Console.ReadLine());

        for (int i = 1; i <= 12; i++)
            Console.Write((n15 * i) + (i < 12 ? ", " : "\n"));

        // Problem 16
       
        Console.Write("Enter a number: ");
        int n16 = int.Parse(Console.ReadLine());

        for (int i = 2; i <= n16; i += 2)
            Console.Write(i + (i < n16 ? ", " : "\n"));

        // Problem 17
      
        Console.Write("Enter base: ");
        int a17 = int.Parse(Console.ReadLine());
        Console.Write("Enter exponent: ");
        int b17 = int.Parse(Console.ReadLine());

        int result17 = 1;
        for (int i = 0; i < b17; i++)
            result17 *= a17;

        Console.WriteLine(result17);

        // Problem 18
        
        Console.Write("Enter a string: ");
        string s18 = Console.ReadLine();
        char[] chars18 = s18.ToCharArray();
        Array.Reverse(chars18);
        Console.WriteLine(new string(chars18));

        // Problem 19
        
        Console.Write("Enter an integer: ");
        string s19 = Console.ReadLine();
        char[] chars19 = s19.ToCharArray();
        Array.Reverse(chars19);
        Console.WriteLine(new string(chars19));

        // Problem 20
       
        Console.Write("Enter array size: ");
        int n20 = int.Parse(Console.ReadLine());
        int[] arr20 = new int[n20];
        for (int i = 0; i < n20; i++)
        {
            Console.Write($"Enter element {i}: ");
            arr20[i] = int.Parse(Console.ReadLine());
        }

        int maxDistance = 0;
        for (int i = 0; i < n20; i++)
        {
            for (int j = i + 1; j < n20; j++)
            {
                if (arr20[i] == arr20[j])
                {
                    int distance = j - i - 1;
                    if (distance > maxDistance)
                        maxDistance = distance;
                }
            }
        }

        Console.WriteLine(maxDistance);

        // Problem 21
       
        Console.Write("Enter a sentence: ");
        string sentence = Console.ReadLine();
        string[] words = sentence.Split(' ');
        Array.Reverse(words);
        Console.WriteLine(string.Join(" ", words));
    }
}