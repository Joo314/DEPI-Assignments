﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace DotNetWithElwakeel
{
    public static class Extensions
    {
        #region Q6
        public static bool IsPalindrome(this string text)
        {
            if (text == null) return false;

            int left = 0;
            int right = text.Length - 1;

            while (left < right)
            {
                if (char.ToLower(text[left]) != char.ToLower(text[right]))
                    return false;

                left++;
                right--;
            }
            return true;
        }
        #endregion

        #region Q7
        public static bool IsPrime(this int number)
        {
            if (number < 2) return false;

            for (int i = 2; i * i <= number; i++)
            {
                if (number % i == 0)
                    return false;
            }
            return true;
        }
        #endregion

        #region Q8
        public static int Sum(this int[] numbers)
        {
            int total = 0;
            foreach (int n in numbers)
                total += n;
            return total;
        }
        #endregion
    }

    #region Q10
    public class Employee
    {
        public string Name { get; set; }
        public decimal Salary { get; set; }
    }
    #endregion

    public class Program
    {
        public static void Main(string[] args)
        {
            Part1_Var();
            Part2_AnonymousTypes();
            Part3_ExtensionMethods();
            Part4_Collections();
        }

        static void Part1_Var()
        {
            #region Q1
            var number = 42;
            var text = "Hello";
            var price = 19.99;
            var isActive = true;
            var scores = new int[] { 90, 80, 70 };

            Console.WriteLine(number.GetType());
            Console.WriteLine(text.GetType());
            Console.WriteLine(price.GetType());
            Console.WriteLine(isActive.GetType());
            Console.WriteLine(scores.GetType());
            #endregion

            #region Q2
            int age1 = 22;
            string name1 = "Joo";
            double gpa1 = 3.5;
            bool passed1 = true;

            var age2 = 22;
            var name2 = "Joo";
            var gpa2 = 3.5;
            var passed2 = true;

            Console.WriteLine(age1.GetType());
            Console.WriteLine(name1.GetType());
            Console.WriteLine(gpa1.GetType());
            Console.WriteLine(passed1.GetType());
            Console.WriteLine(age2.GetType());
            Console.WriteLine(name2.GetType());
            Console.WriteLine(gpa2.GetType());
            Console.WriteLine(passed2.GetType());
            #endregion
        }

        static void Part2_AnonymousTypes()
        {
            #region Q3
            var product = new { Name = "Laptop", Price = 25000.50, Quantity = 3 };
            Console.WriteLine(product.Name);
            Console.WriteLine(product.Price);
            Console.WriteLine(product.Quantity);
            #endregion

            #region Q4
            var students = new[]
            {
                new { Name = "Ahmed", Grade = 88 },
                new { Name = "Sara",  Grade = 95 },
                new { Name = "Omar",  Grade = 72 }
            };

            foreach (var s in students)
                Console.WriteLine($"{s.Name} {s.Grade}");
            #endregion

            #region Q5
            var order = new
            {
                OrderId = 1001,
                Total = 1500.75,
                Customer = new { Name = "Mona", City = "Cairo" }
            };

            Console.WriteLine(order.OrderId);
            Console.WriteLine(order.Total);
            Console.WriteLine($"{order.Customer.Name} {order.Customer.City}");
            #endregion
        }

        static void Part3_ExtensionMethods()
        {
            #region Q6
            string[] words = { "level", "Radar", "hello", "madam", "csharp" };
            foreach (string w in words)
                Console.WriteLine($"{w} {w.IsPalindrome()}");
            #endregion

            #region Q7
            int[] candidates = { 1, 2, 7, 10, 13, 25, 29 };
            foreach (int n in candidates)
                Console.WriteLine($"{n} {n.IsPrime()}");
            #endregion

            #region Q8
            int[] data = { 10, 20, 30, 40, 50 };
            Console.WriteLine(data.Sum());
            #endregion
        }

        static void Part4_Collections()
        {
            #region Q9
            List<string> names = new List<string>();
            names.Add("Ahmed");
            names.Add("Sara");
            names.Add("Omar");
            names.Add("Mona");

            string searchFor = "Omar";
            bool found = false;
            foreach (string n in names)
            {
                if (n == searchFor)
                {
                    found = true;
                    break;
                }
            }
            Console.WriteLine(found);

            string toRemove = "Sara";
            for (int i = 0; i < names.Count; i++)
            {
                if (names[i] == toRemove)
                {
                    names.RemoveAt(i);
                    break;
                }
            }

            foreach (string n in names)
                Console.WriteLine(n);
            #endregion

            #region Q10
            List<Employee> employees = new List<Employee>
            {
                new Employee { Name = "Ahmed", Salary = 8000 },
                new Employee { Name = "Sara",  Salary = 12000 },
                new Employee { Name = "Omar",  Salary = 6500 },
                new Employee { Name = "Mona",  Salary = 15000 }
            };

            decimal minSalary = 9000;
            foreach (Employee e in employees)
            {
                if (e.Salary > minSalary)
                    Console.WriteLine($"{e.Name} {e.Salary}");
            }
            #endregion

            #region Q11
            Dictionary<string, int> prices = new Dictionary<string, int>();
            prices.Add("Keyboard", 500);
            prices.Add("Mouse", 250);
            prices["Monitor"] = 4000;

            foreach (KeyValuePair<string, int> item in prices)
                Console.WriteLine($"{item.Key} {item.Value}");
            #endregion

            #region Q12
            Dictionary<int, string> studentsById = new Dictionary<int, string>
            {
                { 1, "Ahmed" },
                { 2, "Sara" },
                { 3, "Omar" }
            };

            Console.Write("Enter student ID: ");
            string input = Console.ReadLine();

            if (int.TryParse(input, out int id))
            {
                if (studentsById.TryGetValue(id, out string studentName))
                    Console.WriteLine(studentName);
                else
                    Console.WriteLine("Student not found");
            }
            else
            {
                Console.WriteLine("Invalid ID");
            }
            #endregion

            #region Q13
            Hashtable table = new Hashtable();
            table.Add(1, "One");
            table.Add("two", 2);
            table.Add(3.5, true);

            foreach (DictionaryEntry entry in table)
                Console.WriteLine($"{entry.Key} {entry.Value}");
            #endregion

            #region Q14
            Dictionary<string, string> dict = new Dictionary<string, string>();
            dict.Add("EG", "Egypt");
            dict.Add("SA", "Saudi Arabia");

            Hashtable hash = new Hashtable();
            hash.Add("EG", "Egypt");
            hash.Add("SA", "Saudi Arabia");

            string fromDict = dict["EG"];
            string fromHash = (string)hash["EG"];

            Console.WriteLine(fromDict);
            Console.WriteLine(fromHash);
            #endregion
        }
    }
}