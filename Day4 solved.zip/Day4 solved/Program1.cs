using System;

class Program
{
    static void Main(string[] args)
    {
        //////////////////////////////////////////////////////
        // Problem 1: 

        // Way 1
        int[] arr1 = new int[5];
        for (int i = 0; i < arr1.Length; i++)
        {
            arr1[i] = i + 1;
        }

        // Way 2
        int[] arr2 = { 10, 20, 30, 40, 50 };

        // Way 3
        int[] arr3 = [100, 200, 300, 400, 500];

        Console.WriteLine("arr1 (new int[size]): " + string.Join(" ", arr1));
        Console.WriteLine("arr2 (initializer list): " + string.Join(" ", arr2));
        Console.WriteLine("arr3 (array syntax sugar): " + string.Join(" ", arr3));

        // IndexOutOfRangeException
        try
        {
            Console.WriteLine(arr1[10]); // arr1 only has 5 elements (index 0-4)
        }
        catch (IndexOutOfRangeException ex)
        {
            Console.WriteLine("Exception caught: " + ex.Message);
        }

        //  What is the default value assigned to array elements in C#?
        // Answer: For numeric types (int, double, ....) the default value is 0.
        // For bool it is false, for char it is '\0', and for reference types
        // (string, object, custom classes) the default value is null.



        //////////////////////////////////////////////////////
        // Problem 2: 

        int[] original = { 1, 2, 3, 4, 5 };

        int[] shallowCopy = original;
        shallowCopy[0] = 999;

        Console.WriteLine("After shallow copy modification:");
        Console.WriteLine("original[0] = " + original[0]);       // also becomes 999
        Console.WriteLine("shallowCopy[0] = " + shallowCopy[0]);

        int[] deepCopy = (int[])original.Clone();
        deepCopy[1] = 888;

        Console.WriteLine("After deep copy modification:");
        Console.WriteLine("original[1] = " + original[1]);       // stays unchanged
        Console.WriteLine("deepCopy[1] = " + deepCopy[1]);

        // What is the difference between Array.Clone() and Array.Copy()?
        // Answer: Array.Clone() creates a completely new array object and returns it
        // (you must cast the result). Array.Copy() copies elements from an existing
        // source array into an existing destination array that you already created.



        //////////////////////////////////////////////////////
        // Problem 3:

        int students = 3;
        int subjects = 3;
        int[,] grades = new int[students, subjects];

        for (int s = 0; s < students; s++)
        {
            for (int sub = 0; sub < subjects; sub++)
            {
                Console.Write($"Enter grade for student {s + 1}, subject {sub + 1}: ");
                grades[s, sub] = Convert.ToInt32(Console.ReadLine());
            }
        }

        Console.WriteLine("Student grades:");
        for (int s = 0; s < students; s++)
        {
            string row = "";
            for (int sub = 0; sub < subjects; sub++)
            {
                row += grades[s, sub] + " ";
            }
            Console.WriteLine($"Student {s + 1}: {row}");
        }

        // What is the difference between GetLength() and Length for multi-dimensional arrays?
        // Answer: Length returns the TOTAL number of elements in the whole array
        // (all dimensions multiplied together). GetLength(dimension) returns the
        // size of only ONE specific dimension


        //////////////////////////////////////////////////////
        // Problem 4: 

        int[] methodArr = { 5, 3, 8, 1, 9 };
        Console.WriteLine("Before any method: " + string.Join(", ", methodArr));

        Array.Sort(methodArr);
        Console.WriteLine("After Sort: " + string.Join(", ", methodArr));

        Array.Reverse(methodArr);
        Console.WriteLine("After Reverse: " + string.Join(", ", methodArr));

        int position = Array.IndexOf(methodArr, 8);
        Console.WriteLine("Index of value 8: " + position);

        int[] destination = new int[5];
        Array.Copy(methodArr, destination, 3);
        Console.WriteLine("After Copy (first 3 elements): " + string.Join(", ", destination));

        Array.Clear(methodArr, 0, 2);
        Console.WriteLine("After Clear (first 2 elements): " + string.Join(", ", methodArr));

        //  What is the difference between Array.Copy() and Array.ConstrainedCopy()?
        // Answer: Array.Copy() performs the copy and if it fails partway through
        // Array.ConstrainedCopy() guarantees that if the copy
        // fails, the destination array is left completely unchanged (atomic
        // operation), which makes it safer in scenarios requiring strong exception guarantees.



        //////////////////////////////////////////////////////
        // Problem 5: 

        int[] loopArr = { 1, 2, 3, 4, 5 };

        Console.Write("Using for loop: ");
        for (int i = 0; i < loopArr.Length; i++)
        {
            Console.Write(loopArr[i] + " ");
        }
        Console.WriteLine();

        Console.Write("Using foreach loop: ");
        foreach (int x in loopArr)
        {
            Console.Write(x + " ");
        }
        Console.WriteLine();

        Console.Write("Using while loop (reverse order): ");
        int index = loopArr.Length - 1;
        while (index >= 0)
        {
            Console.Write(loopArr[index] + " ");
            index--;
        }
        Console.WriteLine();

        // Why is foreach preferred for read-only operations on arrays?
        // Answer: foreach is simpler and less error-prone because it handles the
        // iteration bounds automatically, removing the risk of off-by-one errors.


        //////////////////////////////////////////////////////
        // Problem 6: 
        int oddNumber;
        bool isValid;

        do
        {
            Console.Write("Enter a positive odd number: ");
            string input = Console.ReadLine();

            isValid = int.TryParse(input, out oddNumber) && oddNumber > 0 && oddNumber % 2 != 0;

            if (!isValid)
            {
                Console.WriteLine("Invalid input. Please enter a positive odd integer.");
            }
        }
        while (!isValid);

        Console.WriteLine("You entered a valid positive odd number: " + oddNumber);

        //  Why is input validation important when working with user inputs?
        // Answer: Users can type anything, including empty strings, letters, or
        // negative numbers. Without validation, the program can crash 
        // or behave incorrectly. Validation ensures the
        // program only processes data that meets its expected format and business
        // rules, which improves reliability, security, and user experience.


        //////////////////////////////////////////////////////
        // Problem 7: 

        int[,] matrix = {
            { 1, 2, 3 },
            { 4, 5, 6 },
            { 7, 8, 9 }
        };

        Console.WriteLine("Matrix format:");
        for (int r = 0; r < matrix.GetLength(0); r++)
        {
            for (int c = 0; c < matrix.GetLength(1); c++)
            {
                Console.Write(matrix[r, c] + "\t");
            }
            Console.WriteLine();
        }

        // How can you format the output of a 2D array for better readability?
        // Answer: Use consistent spacing or tab characters (\t) to align columns,
        // print each row on its own line, and optionally use string formatting
        // methods like PadLeft/PadRight or composite formatting (string.Format
        // or interpolated strings with a fixed width.


        //////////////////////////////////////////////////////
        // Problem 8: 

        string[] monthNames = {
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
        };

        Console.Write("Enter a month number (1-12): ");
        int monthNumber = Convert.ToInt32(Console.ReadLine());

        string monthNameIfElse = (monthNumber >= 1 && monthNumber <= 12)
            ? monthNames[monthNumber - 1]
            : "Invalid month";

        Console.WriteLine("Month name (if-else): " + monthNameIfElse);

        string monthNameSwitch = monthNumber switch
        {
            >= 1 and <= 12 => monthNames[monthNumber - 1],
            _ => "Invalid month"
        };

        Console.WriteLine("Month name (switch): " + monthNameSwitch);

        // When should you prefer a switch statement over if-else?
        // Answer: Prefer switch when checking a single variable against many
        // discrete, known values . It is more readable,
        // easier to maintain, and the compiler can often optimize it 
        // making it faster than a long if-else chain. if-else is better suited
        // for complex conditions or ranges that are not simple equality checks.


        //////////////////////////////////////////////////////
        // Problem 9: 

        int[] searchArr = { 15, 3, 9, 3, 27, 3, 11 };

        Array.Sort(searchArr);
        Console.WriteLine("Sorted array: " + string.Join(", ", searchArr));

        int firstIndex = Array.IndexOf(searchArr, 3);
        int lastIndex = Array.LastIndexOf(searchArr, 3);

        Console.WriteLine("First index of 3: " + firstIndex);
        Console.WriteLine("Last index of 3: " + lastIndex);

        //  What is the time complexity of Array.Sort()?
        // Answer: Array.Sort() uses an introspective sort.Its average and typical time complexity
        // is O(n log n). In rare worst-case scenarios it can degrade, but the
        // introspective approach switches algorithms to avoid quicksort's O(n^2)
        // worst case, keeping it close to O(n log n) in practice.


        //////////////////////////////////////////////////////
        // Problem 10:

        int[] sumArr = { 4, 8, 15, 16, 23, 42 };

        int sumFor = 0;
        for (int i = 0; i < sumArr.Length; i++)
        {
            sumFor += sumArr[i];
        }
        Console.WriteLine("Sum using for loop: " + sumFor);

        int sumForeach = 0;
        foreach (int x in sumArr)
        {
            sumForeach += x;
        }
        Console.WriteLine("Sum using foreach loop: " + sumForeach);

        // Which loop (for or foreach) is more efficient for calculating
        // the sum of an array, and why?
        // Answer: For arrays specifically, a for loop is generally slightly more
        // efficient because it accesses elements directly by index with no
        // iterator overhead. foreach on an array is usually optimized by the
        // compiler to behave similarly to a for loop, so in practice the
        // difference is very small and often negligible.


        //////////////////////////////////////////////////////
        // Part02 - Question 2:

        Console.Write("Enter a day number (1-7): ");
        string dayInput = Console.ReadLine();

        try
        {
            MyDayOfWeek day = (MyDayOfWeek)Enum.Parse(typeof(MyDayOfWeek), dayInput);

            if (Enum.IsDefined(typeof(MyDayOfWeek), day))
            {
                Console.WriteLine("Day: " + day);
            }
            else
            {
                Console.WriteLine("Number is out of the 1-7 range.");
            }
        }
        catch (ArgumentException)
        {
            Console.WriteLine("Invalid input. Please enter a number between 1 and 7.");
        }

        //  What happens if the user enters a value outside the range of 1 to 7?
        // Answer: Enum.Parse does not automatically validate that the number
        // corresponds to a defined enum member. If the input is a number outside 1-7
        // Enum.Parse will still succeed and create an enum
        // value of 9, even though it has no matching name. This is why
        // Enum.IsDefined must be used afterward to check whether the resulting
        // value is actually a valid, defined enum member; otherwise the program
        // may behave incorrectly with an undefined value. If the input is not a
        // number and not a valid enum name at all, Enum.Parse throws an
        // ArgumentException.

        Console.WriteLine();
        Console.WriteLine("Program finished.");
    }
}

// Part02 Question 2.
enum MyDayOfWeek
{
    Monday = 1,
    Tuesday = 2,
    Wednesday = 3,
    Thursday = 4,
    Friday = 5,
    Saturday = 6,
    Sunday = 7
}
