﻿using System;

namespace Day7
{
    #region 1
    class Car
    {
        public int Id { get; set; }
        public string Brand { get; set; }
        public double Price { get; set; }

        public Car()
        {
            Id = 0;
            Brand = "Unknown";
            Price = 0;
        }

        public Car(int id)
        {
            Id = id;
            Brand = "Unknown";
            Price = 0;
        }

        public Car(int id, string brand)
        {
            Id = id;
            Brand = brand;
            Price = 0;
        }

        public Car(int id, string brand, double price)
        {
            Id = id;
            Brand = brand;
            Price = price;
        }

        public override string ToString()
        {
            return $"Id={Id}, Brand={Brand}, Price={Price}";
        }
    }
    #endregion

    #region 2
    class Calculator
    {
        public int Sum(int a, int b)
        {
            return a + b;
        }

        public int Sum(int a, int b, int c)
        {
            return a + b + c;
        }

        public double Sum(double a, double b)
        {
            return a + b;
        }
    }
    #endregion

    #region 3
    class Parent
    {
        public int X { get; set; }
        public int Y { get; set; }

        public Parent(int x, int y)
        {
            X = x;
            Y = y;
        }
    }

    class Child : Parent
    {
        public int Z { get; set; }

        public Child(int x, int y, int z) : base(x, y)
        {
            Z = z;
        }
    }
    #endregion

    #region 4
    class Parent4
    {
        public int X { get; set; }
        public int Y { get; set; }

        public Parent4(int x, int y)
        {
            X = x;
            Y = y;
        }

        public virtual int Product()
        {
            return X * Y;
        }
    }

    class ChildNew : Parent4
    {
        public int Z { get; set; }

        public ChildNew(int x, int y, int z) : base(x, y)
        {
            Z = z;
        }

        public new int Product()
        {
            return X * Y * Z;
        }
    }

    class ChildOverride : Parent4
    {
        public int Z { get; set; }

        public ChildOverride(int x, int y, int z) : base(x, y)
        {
            Z = z;
        }

        public override int Product()
        {
            return X * Y * Z;
        }
    }
    #endregion

    #region 5
    class Parent5
    {
        public int X { get; set; }
        public int Y { get; set; }

        public Parent5(int x, int y)
        {
            X = x;
            Y = y;
        }

        public override string ToString()
        {
            return $"({X}, {Y})";
        }
    }

    class Child5 : Parent5
    {
        public int Z { get; set; }

        public Child5(int x, int y, int z) : base(x, y)
        {
            Z = z;
        }

        public override string ToString()
        {
            return $"({X}, {Y}, {Z})";
        }
    }
    #endregion

    #region 6
    interface IShape
    {
        double Area { get; }
        void Draw();
    }

    class Rectangle : IShape
    {
        public double Width { get; set; }
        public double Height { get; set; }

        public Rectangle(double width, double height)
        {
            Width = width;
            Height = height;
        }

        public double Area
        {
            get { return Width * Height; }
        }

        public void Draw()
        {
            Console.WriteLine("Drawing a Rectangle");
        }
    }
    #endregion

    #region 7
    interface IShapeDefault
    {
        double Area { get; }
        void Draw();

        void PrintDetails()
        {
            Console.WriteLine($"Shape area = {Area}");
        }
    }

    class Circle : IShapeDefault
    {
        public double Radius { get; set; }

        public Circle(double radius)
        {
            Radius = radius;
        }

        public double Area
        {
            get { return Math.PI * Radius * Radius; }
        }

        public void Draw()
        {
            Console.WriteLine("Drawing a Circle");
        }
    }
    #endregion

    #region 8
    interface IMovable
    {
        void Move();
    }

    class MovableCar : IMovable
    {
        public void Move()
        {
            Console.WriteLine("Car is moving");
        }
    }
    #endregion

    #region 9
    interface IReadable
    {
        void Read();
    }

    interface IWritable
    {
        void Write();
    }

    class File : IReadable, IWritable
    {
        public void Read()
        {
            Console.WriteLine("Reading from file");
        }

        public void Write()
        {
            Console.WriteLine("Writing to file");
        }
    }
    #endregion

    #region 10
    abstract class Shape
    {
        public virtual void Draw()
        {
            Console.WriteLine("Drawing Shape");
        }

        public abstract double CalculateArea();
    }

    class ShapeRectangle : Shape
    {
        public double Width { get; set; }
        public double Height { get; set; }

        public ShapeRectangle(double width, double height)
        {
            Width = width;
            Height = height;
        }

        public override void Draw()
        {
            Console.WriteLine("Drawing Rectangle");
        }

        public override double CalculateArea()
        {
            return Width * Height;
        }
    }
    #endregion

    class Program
    {
        static void Main(string[] args)
        {
            #region 1
            Console.WriteLine("---- Car Constructors ----");

            Car car1 = new Car();
            Car car2 = new Car(1);
            Car car3 = new Car(2, "Toyota");
            Car car4 = new Car(3, "BMW", 55000);

            Console.WriteLine(car1);
            Console.WriteLine(car2);
            Console.WriteLine(car3);
            Console.WriteLine(car4);
            Console.WriteLine();
            #endregion

            #region 2
            Console.WriteLine("---- Calculator Overload ----");

            Calculator calc = new Calculator();

            Console.WriteLine("Sum(2, 3) = " + calc.Sum(2, 3));
            Console.WriteLine("Sum(2, 3, 4) = " + calc.Sum(2, 3, 4));
            Console.WriteLine("Sum(2.5, 3.5) = " + calc.Sum(2.5, 3.5));
            Console.WriteLine();
            #endregion

            #region 3
            Console.WriteLine("---- Constructor Chaining ----");

            Child child = new Child(1, 2, 3);
            Console.WriteLine($"X={child.X}, Y={child.Y}, Z={child.Z}");
            Console.WriteLine();
            #endregion

            #region 4
            Console.WriteLine("---- new vs override ----");

            ChildNew cn = new ChildNew(2, 3, 4);
            Parent4 pRefNew = cn;

            Console.WriteLine("ChildNew via Child reference: " + cn.Product());
            Console.WriteLine("ChildNew via Parent reference: " + pRefNew.Product());

            ChildOverride co = new ChildOverride(2, 3, 4);
            Parent4 pRefOverride = co;

            Console.WriteLine("ChildOverride via Child reference: " + co.Product());
            Console.WriteLine("ChildOverride via Parent reference: " + pRefOverride.Product());
            Console.WriteLine();
            #endregion

            #region 5
            Console.WriteLine("---- ToString Polymorphism ----");

            Parent5 parent = new Parent5(1, 2);
            Parent5 childAsParent = new Child5(1, 2, 3);

            Console.WriteLine(parent);
            Console.WriteLine(childAsParent);
            Console.WriteLine();
            #endregion

            #region 6
            Console.WriteLine("---- IShape / Rectangle ----");

            IShape shape = new Rectangle(4, 5);
            shape.Draw();
            Console.WriteLine("Area = " + shape.Area);
            Console.WriteLine();
            #endregion

            #region 7
            Console.WriteLine("---- IShape Default Implementation / Circle ----");

            IShapeDefault circle = new Circle(3);
            circle.Draw();
            circle.PrintDetails();
            Console.WriteLine();
            #endregion

            #region 8
            Console.WriteLine("---- IMovable / Car ----");

            IMovable movable = new MovableCar();
            movable.Move();
            Console.WriteLine();
            #endregion

            #region 9
            Console.WriteLine("---- IReadable / IWritable / File ----");

            File file = new File();
            file.Read();
            file.Write();
            Console.WriteLine();
            #endregion

            #region 10
            Console.WriteLine("---- Virtual / Abstract Shape ----");

            ShapeRectangle rectangle = new ShapeRectangle(6, 7);
            rectangle.Draw();
            Console.WriteLine("Area = " + rectangle.CalculateArea());
            Console.WriteLine();
            #endregion
        }
    }
}