﻿using System;

namespace Day6
{
    struct Point
    {
        public int X;
        public int Y;

        public Point(int x)
        {
            X = x;
            Y = 0;
        }

        public Point(int x, int y)
        {
            X = x;
            Y = y;
        }

        public override string ToString()
        {
            return $"({X}, {Y})";
        }
    }

    class TypeA
    {
        private int F;
        internal int G;
        public int H;

        public TypeA(int f, int g, int h)
        {
            F = f;
            G = g;
            H = h;
        }

        public void Print()
        {
            Console.WriteLine($"F={F}, G={G}, H={H}");
        }
    }

    class TypeB
    {
        public void Print(TypeA obj)
        {
            //Console.WriteLine(obj.F); // error, F is private
            Console.WriteLine(obj.G);
            Console.WriteLine(obj.H);
        }
    }

    struct Employee
    {
        private int EmpId;
        private string EmpName;
        private decimal EmpSalary;

        public string GetName()
        {
            return EmpName;
        }

        public void SetName(string value)
        {
            EmpName = value.Length <= 10 ? value : value.Substring(0, 10);
        }

        public decimal Salary
        {
            get { return EmpSalary; }
            set { EmpSalary = value < 6000 ? 6000 : value; }
        }
    }

    class Program
    {
        static void Main()
        {
            #region Problem 1
            Point p1 = new Point();
            Console.WriteLine(p1);

            Point p2 = new Point(2, 4);
            Console.WriteLine(p2);
            #endregion

            #region Problem 2
            TypeA a = new TypeA(1, 2, 3);
            a.Print();

            TypeB b = new TypeB();
            b.Print(a);
            #endregion

            #region Problem 3
            Employee emp = new Employee();

            emp.SetName("AbdelrahmanElwakeel");
            Console.WriteLine(emp.GetName());

            emp.Salary = 5000;
            Console.WriteLine(emp.Salary);
            #endregion

            #region Problem 4
            Point p3 = new Point(5);
            Console.WriteLine(p3);

            Point p4 = new Point(2, 4);
            Console.WriteLine(p4);
            #endregion

            #region Problem 5
            Point[] points = { new Point(1, 1), new Point(2, 4), new Point(0, 9) };
            foreach (var p in points)
                Console.WriteLine(p);
            #endregion
        }
    }
}