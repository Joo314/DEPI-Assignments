﻿using System;
using System.Collections.Generic;

namespace Day9
{
    #region Part01 - Q1: Weekdays Enum
    enum Weekdays
    {
        Monday = 1,
        Tuesday,
        Wednesday,
        Thursday,
        Friday
    }
    #endregion

    #region Part01 - Q2 & Q9: Grades Enum (short, F = -1) + TryParse
    enum Grades : short
    {
        A = 90,
        B = 80,
        C = 70,
        D = 60,
        F = -1
    }
    #endregion

    #region Part01 - Q3: Person with Department property
    class Person
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public string Department { get; set; }

        public virtual void Display()
        {
            Console.WriteLine($"Name: {Name}, Age: {Age}, Department: {Department}");
        }
    }
    #endregion

    #region Part01 - Q4: Employee2 base + Child with sealed Salary
    class Employee2
    {
        public virtual double Salary { get; set; } = 5000;
    }

    class Child : Employee2
    {
        public sealed override double Salary
        {
            get { return base.Salary; }
            set { base.Salary = value; }
        }

        public void DisplaySalary()
        {
            Console.WriteLine($"Salary: {Salary}");
        }
    }
    #endregion

    #region Part01 - Q5 & Q8: Utility static class (Perimeter + Temperature conversion)
    static class Utility
    {
        public static double CalculatePerimeter(double length, double width)
        {
            return 2 * (length + width);
        }

        public static double CelsiusToFahrenheit(double celsius) => (celsius * 9 / 5) + 32;

        public static double FahrenheitToCelsius(double fahrenheit) => (fahrenheit - 32) * 5 / 9;
    }
    #endregion

    #region Part01 - Q6: ComplexNumber with operator *
    class ComplexNumber
    {
        public double Real { get; set; }
        public double Imaginary { get; set; }

        public ComplexNumber(double real, double imaginary)
        {
            Real = real;
            Imaginary = imaginary;
        }

        public static ComplexNumber operator +(ComplexNumber a, ComplexNumber b)
        {
            return new ComplexNumber(a.Real + b.Real, a.Imaginary + b.Imaginary);
        }

        public static ComplexNumber operator *(ComplexNumber a, ComplexNumber b)
        {
            double real = a.Real * b.Real - a.Imaginary * b.Imaginary;
            double imaginary = a.Real * b.Imaginary + a.Imaginary * b.Real;
            return new ComplexNumber(real, imaginary);
        }

        public override string ToString() => $"{Real} + {Imaginary}i";
    }
    #endregion

    #region Part01 - Q7: Gender Enum (byte)
    enum Gender : byte
    {
        Male = 0,
        Female = 1
    }
    #endregion

    #region Part01 - Q14: Department class
    class Department
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public Department(int id, string name)
        {
            Id = id;
            Name = name;
        }

        public override bool Equals(object obj)
        {
            if (obj is Department other)
                return Id == other.Id && Name == other.Name;
            return false;
        }

        public override int GetHashCode() => HashCode.Combine(Id, Name);
        public override string ToString() => Name;
    }
    #endregion

    #region Part01 - Q10 & Q14: Employee with Equals + Department
    class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public Department Department { get; set; }

        public Employee(int id, string name, Department department)
        {
            Id = id;
            Name = name;
            Department = department;
        }

        public override bool Equals(object obj)
        {
            if (obj is Employee other)
                return Id == other.Id && Name == other.Name;
            return false;
        }

        public override int GetHashCode() => HashCode.Combine(Id, Name);
        public override string ToString() => $"{Id} - {Name} - {Department}";
    }
    #endregion

    #region Part01 - Q11 & Part02 Q4: Helper generic Max / FindMax
    static class Helper
    {
        public static T Max<T>(T a, T b) where T : IComparable<T>
        {
            return a.CompareTo(b) >= 0 ? a : b;
        }
    }
    #endregion

    #region Part01 - Q10 & Q12: Helper2<T> generic class (SearchArray, ReplaceArray)
    static class Helper2<T>
    {
        public static bool SearchArray(T[] array, T target)
        {
            foreach (T item in array)
                if (item.Equals(target)) return true;
            return false;
        }

        public static void ReplaceArray(T[] array, T oldValue, T newValue)
        {
            for (int i = 0; i < array.Length; i++)
            {
                if (array[i].Equals(oldValue))
                    array[i] = newValue;
            }
        }
    }
    #endregion

    #region Part01 - Q13: RectangleData struct + non-generic Swap
    struct RectangleData
    {
        public double Length { get; set; }
        public double Width { get; set; }
    }

    static class RectangleHelper
    {
        public static void Swap(ref RectangleData a, ref RectangleData b)
        {
            RectangleData temp = a;
            a = b;
            b = temp;
        }
    }
    #endregion

    #region Part01 - Q15: CircleStruct vs CircleClass (== and Equals)
    struct CircleStruct
    {
        public double Radius { get; set; }
        public string Color { get; set; }
    }

    class CircleClass
    {
        public double Radius { get; set; }
        public string Color { get; set; }
    }
    #endregion

    #region Part02 - Q1, Q3, Q4: ArrayHelper (Reverse, Swap<T>, FindMax<T>)
    static class ArrayHelper
    {
        public static T[] ReverseArray<T>(T[] array)
        {
            T[] result = new T[array.Length];
            for (int i = 0; i < array.Length; i++)
            {
                result[array.Length - 1 - i] = array[i];
            }
            return result;
        }

        public static void Swap<T>(T[] array, int index1, int index2)
        {
            T temp = array[index1];
            array[index1] = array[index2];
            array[index2] = temp;
        }

        public static T FindMax<T>(T[] array) where T : IComparable<T>
        {
            T max = array[0];
            foreach (T item in array)
            {
                if (item.CompareTo(max) > 0)
                    max = item;
            }
            return max;
        }
    }
    #endregion

    #region Part02 - Q2: Generic Stack (renamed MyStack to avoid clashing with System.Collections.Generic.Stack<T>)
    class MyStack<T>
    {
        private List<T> items = new List<T>();

        public void Push(T item) => items.Add(item);

        public T Pop()
        {
            if (items.Count == 0)
                throw new InvalidOperationException("Stack is empty.");
            T item = items[^1];
            items.RemoveAt(items.Count - 1);
            return item;
        }

        public T Peek()
        {
            if (items.Count == 0)
                throw new InvalidOperationException("Stack is empty.");
            return items[^1];
        }

        public int Count => items.Count;
    }
    #endregion

    class Program
    {
        static void Main(string[] args)
        {
            #region Part01 - Q1: Weekdays
            Console.WriteLine(" Weekdays Enum ==");
            foreach (Weekdays day in Enum.GetValues(typeof(Weekdays)))
            {
                Console.WriteLine($"{day} = {(int)day}");
            }
            Console.WriteLine();
            #endregion

            #region Part01 - Q2: Grades (short, F = -1)
            Console.WriteLine(" Grades Enum (short) ==");
            foreach (Grades g in Enum.GetValues(typeof(Grades)))
            {
                Console.WriteLine($"{g} = {(short)g}");
            }
            Console.WriteLine();
            #endregion

            #region Part01 - Q3: Person + Department
            Console.WriteLine(" Person with Department ==");
            Person p1 = new Person { Name = "Ahmed", Age = 25, Department = "IT" };
            Person p2 = new Person { Name = "Sara", Age = 30, Department = "HR" };
            p1.Display();
            p2.Display();
            Console.WriteLine();
            #endregion

            #region Part01 - Q4: Child DisplaySalary
            Console.WriteLine(" Child with sealed Salary ==");
            Child c = new Child();
            c.Salary = 7000;
            c.DisplaySalary();
            Console.WriteLine();
            #endregion

            #region Part01 - Q5: Utility Perimeter
            Console.WriteLine(" Utility.CalculatePerimeter ==");
            double perimeter = Utility.CalculatePerimeter(5, 3);
            Console.WriteLine($"Perimeter = {perimeter}");
            Console.WriteLine();
            #endregion

            #region Part01 - Q6: ComplexNumber multiplication
            Console.WriteLine(" ComplexNumber operator * ==");
            ComplexNumber cn1 = new ComplexNumber(2, 3);
            ComplexNumber cn2 = new ComplexNumber(1, 4);
            Console.WriteLine($"({cn1}) * ({cn2}) = {cn1 * cn2}");
            Console.WriteLine();
            #endregion

            #region Part01 - Q7: Gender byte enum
            Console.WriteLine(" Gender Enum (byte) ==");
            Console.WriteLine($"Gender (byte-based) uses {sizeof(byte)} byte(s) per value.");
            Console.WriteLine($"Default int-based enum uses {sizeof(int)} byte(s) per value.");
            Console.WriteLine();
            #endregion

            #region Part01 - Q8: Temperature conversion
            Console.WriteLine("Temperature Conversion ==");
            Console.WriteLine($"25 C = {Utility.CelsiusToFahrenheit(25)} F");
            Console.WriteLine($"77 F = {Utility.FahrenheitToCelsius(77)} C");
            Console.WriteLine();
            #endregion

            #region Part01 - Q9: Enum.TryParse
            Console.WriteLine(" Enum.TryParse ==");
            string input = "B";
            if (Enum.TryParse<Grades>(input, out Grades grade))
                Console.WriteLine($"Parsed successfully: {grade}");
            else
                Console.WriteLine("Invalid grade value.");
            Console.WriteLine();
            #endregion

            #region Part01 - Q10: Employee.Equals + Helper2<Employee>.SearchArray
            Console.WriteLine(" Employee Equals + SearchArray ==");
            Department itDept = new Department(1, "IT");
            Department hrDept = new Department(2, "HR");

            Employee[] employees = {
                new Employee(1, "Ali", itDept),
                new Employee(2, "Sara", hrDept)
            };

            Employee searchTarget = new Employee(2, "Sara", hrDept);
            bool foundEmployee = Helper2<Employee>.SearchArray(employees, searchTarget);
            Console.WriteLine(foundEmployee ? "Employee found" : "Employee not found");
            Console.WriteLine();
            #endregion

            #region Part01 - Q11: Helper.Max generic method
            Console.WriteLine(" Helper.Max<T> ==");
            Console.WriteLine(Helper.Max(5, 10));
            Console.WriteLine(Helper.Max(3.5, 2.1));
            Console.WriteLine(Helper.Max("apple", "banana"));
            Console.WriteLine();
            #endregion

            #region Part01 - Q12: Helper2<T>.ReplaceArray
            Console.WriteLine("Helper2<T>.ReplaceArray ==");
            int[] numbersToReplace = { 1, 2, 3, 2, 5 };
            Helper2<int>.ReplaceArray(numbersToReplace, 2, 99);
            Console.WriteLine(string.Join(", ", numbersToReplace));

            string[] wordsToReplace = { "cat", "dog", "cat" };
            Helper2<string>.ReplaceArray(wordsToReplace, "cat", "lion");
            Console.WriteLine(string.Join(", ", wordsToReplace));
            Console.WriteLine();
            #endregion

            #region Part01 - Q13: RectangleData Swap
            Console.WriteLine(" RectangleData Swap ==");
            RectangleData r1 = new RectangleData { Length = 10, Width = 5 };
            RectangleData r2 = new RectangleData { Length = 20, Width = 8 };
            RectangleHelper.Swap(ref r1, ref r2);
            Console.WriteLine($"r1: {r1.Length}x{r1.Width}");
            Console.WriteLine($"r2: {r2.Length}x{r2.Width}");
            Console.WriteLine();
            #endregion

            #region Part01 - Q14: Search Employees by Department
            Console.WriteLine(" Search by Department ==");
            Employee deptSearchTarget = new Employee(0, "", itDept);
            bool foundInIT = false;
            foreach (var emp in employees)
            {
                if (emp.Department.Equals(itDept))
                {
                    foundInIT = true;
                    break;
                }
            }
            Console.WriteLine(foundInIT ? "Found employee in IT" : "Not found");
            Console.WriteLine();
            #endregion

            #region Part01 - Q15: CircleStruct vs CircleClass
            Console.WriteLine(" CircleStruct vs CircleClass ==");
            CircleStruct cs1 = new CircleStruct { Radius = 5, Color = "Red" };
            CircleStruct cs2 = new CircleStruct { Radius = 5, Color = "Red" };
            Console.WriteLine($"Struct Equals: {cs1.Equals(cs2)}"); // True (value comparison)
            // cs1 == cs2 would be a compile error: == not defined by default for structs

            CircleClass cc1 = new CircleClass { Radius = 5, Color = "Red" };
            CircleClass cc2 = new CircleClass { Radius = 5, Color = "Red" };
            Console.WriteLine($"Class Equals: {cc1.Equals(cc2)}"); // False (reference comparison)
            Console.WriteLine($"Class ==: {cc1 == cc2}");          // False (reference comparison)
            Console.WriteLine();
            #endregion

            #region Part02 - Q1: ReverseArray<T>
            Console.WriteLine(" ReverseArray<T> ==");
            int[] numsToReverse = { 1, 2, 3, 4, 5 };
            Console.WriteLine(string.Join(", ", ArrayHelper.ReverseArray(numsToReverse)));

            string[] wordsToReverse = { "one", "two", "three" };
            Console.WriteLine(string.Join(", ", ArrayHelper.ReverseArray(wordsToReverse)));
            Console.WriteLine();
            #endregion

            #region Part02 - Q2: MyStack<T>
            Console.WriteLine(" MyStack<T> ==");
            MyStack<int> stack = new MyStack<int>();
            stack.Push(1);
            stack.Push(2);
            stack.Push(3);
            Console.WriteLine($"Peek: {stack.Peek()}");
            Console.WriteLine($"Pop: {stack.Pop()}");
            Console.WriteLine($"Count: {stack.Count}");
            Console.WriteLine();
            #endregion

            #region Part02 - Q3: Swap<T> elements in array
            Console.WriteLine(" Swap<T> ==");
            int[] numsToSwap = { 1, 2, 3, 4 };
            ArrayHelper.Swap(numsToSwap, 0, 3);
            Console.WriteLine(string.Join(", ", numsToSwap));
            Console.WriteLine();
            #endregion

            #region Part02 - Q4: FindMax<T>
            Console.WriteLine(" FindMax<T> ==");
            int[] intsForMax = { 3, 7, 2, 9, 4 };
            Console.WriteLine(ArrayHelper.FindMax(intsForMax)); // 9

            double[] doublesForMax = { 1.5, 3.2, 2.8 };
            Console.WriteLine(ArrayHelper.FindMax(doublesForMax)); // 3.2
            Console.WriteLine();
            #endregion
        }
    }
}