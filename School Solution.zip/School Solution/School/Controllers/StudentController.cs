﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using School.Data;
using School.Models;
using System.Collections.Generic;
using System.Reflection.Emit;

namespace School.Controllers
{
    public class StudentController : Controller
    {
        private readonly SchoolDbContext _context;

        public StudentController(SchoolDbContext context) => _context = context;

        // /Student/ShowAll
        public IActionResult ShowAll()
        {
            var students = _context.Students
                .Include(s => s.Department)
                .AsNoTracking()
                .ToList();
            return View(students);
        }

        // /Student/ShowDetails?id=3
        public IActionResult ShowDetails(int id)
        {
            var student = _context.Students
                .Include(s => s.Department)
                .Include(s => s.StuCrsRes).ThenInclude(r => r.Course)
                .AsNoTracking()
                .FirstOrDefault(s => s.Id == id);

            if (student == null) return NotFound($"No student with id {id}");
            return View(student);
        }
    }
}
