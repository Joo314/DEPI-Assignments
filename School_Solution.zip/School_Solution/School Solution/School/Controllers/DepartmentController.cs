﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using School.Data;
using School.Models;
using School.ViewModels;

namespace School.Controllers
{
    public class DepartmentController : Controller
    {
        private readonly SchoolDbContext _context;

        public DepartmentController(SchoolDbContext context) => _context = context;

        // /Department/ShowAll
        public IActionResult ShowAll()
        {
            var departments = _context.Departments
                .Include(d => d.Students)
                .AsNoTracking()
                .ToList();
            return View(departments);
        }

        // /Department/ShowDetails?id=1
        public IActionResult ShowDetails(int id)
        {
            var department = _context.Departments
                .Include(d => d.Students)
                .AsNoTracking()
                .FirstOrDefault(d => d.Id == id);

            if (department == null) return NotFound($"No department with id {id}");
            return View(department);
        }

        // GET: /Department/Add
        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }

        // POST: /Department/Add
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Add(Department department)
        {
            if (!ModelState.IsValid) return View(department);

            _context.Departments.Add(department);
            _context.SaveChanges();
            return RedirectToAction("ShowAll");
        }

        // /Department/ShowStudents?id=1
        public IActionResult ShowStudents(int id)
        {
            var department = _context.Departments
                .Include(d => d.Students)
                .AsNoTracking()
                .FirstOrDefault(d => d.Id == id);

            if (department == null) return NotFound($"No department with id {id}");

            var viewModel = new DepartmentStudentsViewModel();
            viewModel.DepartmentName = department.Name;
            viewModel.Students = department.Students
                .Where(s => s.Age > 25)
                .Select(s => new SelectListItem { Value = s.Id.ToString(), Text = s.Name })
                .ToList();
            viewModel.State = department.Students.Count > 50 ? "Main" : "Branch";

            return View(viewModel);
        }
    }
}
