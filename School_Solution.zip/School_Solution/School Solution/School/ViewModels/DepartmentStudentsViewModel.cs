﻿using Microsoft.AspNetCore.Mvc.Rendering;

namespace School.ViewModels
{
    public class DepartmentStudentsViewModel
    {
        public string DepartmentName { get; set; } = null!;
        public List<SelectListItem> Students { get; set; } = new List<SelectListItem>();
        public string State { get; set; } = null!;
    }
}
