﻿using Microsoft.EntityFrameworkCore;
using School.Models;
using System.Collections.Generic;
using System.Reflection.Emit;

namespace School.Data
{
    public class SchoolDbContext: DbContext
    {
        public SchoolDbContext(DbContextOptions<SchoolDbContext> options) : base(options) { }

        public DbSet<Department> Departments => Set<Department>();
        public DbSet<Student> Students => Set<Student>();
        public DbSet<Course> Courses => Set<Course>();
        public DbSet<Teacher> Teachers => Set<Teacher>();
        public DbSet<StuCrsRes> StuCrsRes => Set<StuCrsRes>();

        protected override void OnModelCreating(ModelBuilder mb)
        {
            
            mb.Entity<StuCrsRes>().HasKey(x => new { x.StudentId, x.CourseId });

            mb.Entity<Teacher>().Property(t => t.Salary).HasPrecision(18, 2);

            
            foreach (var fk in mb.Model.GetEntityTypes().SelectMany(e => e.GetForeignKeys()))
                fk.DeleteBehavior = DeleteBehavior.Restrict;

            // Sample data so the pages are not empty
            mb.Entity<Department>().HasData(
                new Department { Id = 1, Name = "Computer Science", MgrName = "Dr. Ahmed" },
                new Department { Id = 2, Name = "Information Systems", MgrName = "Dr. Mona" });

            mb.Entity<Course>().HasData(
                new Course { Id = 1, Name = "C#", Degree = 100, MinDegree = 50, DepartmentId = 1 },
                new Course { Id = 2, Name = "Databases", Degree = 100, MinDegree = 50, DepartmentId = 1 },
                new Course { Id = 3, Name = "Web Development", Degree = 100, MinDegree = 60, DepartmentId = 2 });

            mb.Entity<Student>().HasData(
                new Student { Id = 1, Name = "Ali", Age = 20, DepartmentId = 1 },
                new Student { Id = 2, Name = "Sara", Age = 21, DepartmentId = 1 },
                new Student { Id = 3, Name = "Omar", Age = 22, DepartmentId = 2 },
                new Student { Id = 4, Name = "Nour", Age = 20, DepartmentId = 2 },
                new Student { Id = 5, Name = "Khaled", Age = 27, DepartmentId = 1 },
                new Student { Id = 6, Name = "Laila", Age = 30, DepartmentId = 1 });

            mb.Entity<Teacher>().HasData(
                new Teacher { Id = 1, Name = "Mohamed", Salary = 12000m, Address = "Cairo", CourseId = 1, DepartmentId = 1 },
                new Teacher { Id = 2, Name = "Heba", Salary = 11000m, Address = "Giza", CourseId = 3, DepartmentId = 2 });

            mb.Entity<StuCrsRes>().HasData(
                new StuCrsRes { StudentId = 1, CourseId = 1, Grade = 85 },
                new StuCrsRes { StudentId = 1, CourseId = 2, Grade = 70 },
                new StuCrsRes { StudentId = 2, CourseId = 1, Grade = 45 },
                new StuCrsRes { StudentId = 3, CourseId = 3, Grade = 90 },
                new StuCrsRes { StudentId = 4, CourseId = 3, Grade = 58 });
        }
    }
}
