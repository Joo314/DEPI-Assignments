﻿using day10_G01;
using System;
using System.Collections.Generic;
using System.Linq;
namespace LINQ1
{
    class CaseInsensitiveComparer : IComparer<string>
    {
        public int Compare(string x, string y)
        {
            return string.Compare(x, y, StringComparison.OrdinalIgnoreCase);
        }
    }
    class Program
    {
        static void Print<T>(IEnumerable<T> source)
        {
           // foreach (var item in source)
               // Console.WriteLine(item);
        }
        static void Main(string[] args)
        {
            var products = ListGenerators.ProductList;
            //            #region Restriction 1
            //            var r1 = products.Where(p => p.UnitsInStock == 0);
            //            Print(r1);
            //            #endregion
            //            #region Restriction 2
            //            var r2 = products.Where(p => p.UnitsInStock > 0 && p.UnitPrice > 3.00M);
            //            Print(r2);
            //            #endregion
            //            #region Restriction 3
            //            string[] digits = { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine" };
            //            var r3 = digits.Where((d, i) => d.Length < i);
            //            Print(r3);
            //            #endregion
            //            #region Element 1
            //            var e1 = products.First(p => p.UnitsInStock == 0);
            //            Console.WriteLine(e1);
            //            #endregion
            //            #region Element 2
            //            var e2 = products.FirstOrDefault(p => p.UnitPrice > 1000);
            //            Console.WriteLine(e2 == null ? "null" : e2.ToString());
            //            #endregion
            //            #region Element 3
            //            int[] eNums = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
            //            var e3 = eNums.Where(n => n > 5).Skip(1).First();
            //            Console.WriteLine(e3);
            //            #endregion
            //            #region Aggregate 1
            //            int[] aNums = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
            //            var a1 = aNums.Count(n => n % 2 != 0);
            //            Console.WriteLine(a1);
            //            #endregion
            //            #region Aggregate 3
            //            var a3 = products.GroupBy(p => p.Category)
            //                             .Select(g => new { Category = g.Key, ProductsCount = g.Count() });
            //            Print(a3);
            //            #endregion
            //            #region Aggregate 4
            //            var a4 = aNums.Sum();
            //            Console.WriteLine(a4);
            //            #endregion
            //            #region Aggregate 6
            //            var a6 = products.GroupBy(p => p.Category)
            //                             .Select(g => new { Category = g.Key, TotalUnits = g
            //                             .Sum(p => p.UnitsInStock) });
            //            Print(a6);
            //            #endregion
            //            #region Aggregate 8
            //            var a8 = products.GroupBy(p => p.Category)
            //                             .Select(g => new { Category = g.Key, CheapestPrice = g.Min(p => p.UnitPrice) });
            //            Print(a8);
            //            #endregion
            //            #region Aggregate 9
            //            var a9 = from p in products
            //                     group p by p.Category into g
            //                     let minPrice = g.Min(x => x.UnitPrice)
            //                     select new { Category = g.Key, Items = g
            //                     .Where(x => x.UnitPrice == minPrice) };
            //            foreach (var g in a9)
            //            {
            //                Console.WriteLine(g.Category);
            //                Print(g.Items);
            //            }
            //            #endregion
            //            #region Aggregate 11
            //            var a11 = products.GroupBy(p => p.Category)
            //                              .Select(g => new { Category = g.Key, MostExpensivePrice = g.Max(p => p.UnitPrice) });
            //            Print(a11);
            //            #endregion
            //            #region Aggregate 12
            //            var a12 = from p in products
            //                      group p by p.Category into g
            //                      let maxPrice = g.Max(x => x.UnitPrice)
            //                      select new { Category = g.Key, Items = g.Where(x => x.UnitPrice == maxPrice) };
            //            foreach (var g in a12)
            //            {
            //                Console.WriteLine(g.Category);
            //                Print(g.Items);
            //            }
            //            #endregion
            //            #region Aggregate 14
            //            var a14 = products.GroupBy(p => p.Category)
            //                              .Select(g => new { Category = g.Key, AveragePrice = g.Average(p => p.UnitPrice) });
            //            Print(a14);
            //            #endregion
            //            #region Ordering 1
            //            var o1 = products.OrderBy(p => p.ProductName);
            //            Print(o1);
            //            #endregion
            //            #region Ordering 2
            //            string[] oWords = { "aPPLE", "AbAcUs", "bRaNcH", "BlUeBeRrY", "ClOvEr", "cHeRry" };
            //            var o2 = oWords.OrderBy(w => w, new CaseInsensitiveComparer());
            //            Print(o2);
            //            #endregion
            //            #region Ordering 3
            //            var o3 = products.OrderByDescending(p => p.UnitsInStock);
            //            Print(o3);
            //            #endregion
            //            #region Ordering 4
            //            var o4 = digits.OrderBy(d => d.Length).ThenBy(d => d);
            //            Print(o4);
            //            #endregion
            //            #region Ordering 5
            //            var o5 = oWords.OrderBy(w => w.Length).ThenBy(w => w, new CaseInsensitiveComparer());
            //            Print(o5);
            //            #endregion
            //            #region Ordering 6
            //            var o6 = products.OrderBy(p => p.Category).ThenByDescending(p => p.UnitPrice);
            //            Print(o6);
            //            #endregion
            //            #region Ordering 7
            //            var o7 = oWords.OrderBy(w => w.Length).ThenByDescending(w => w, new CaseInsensitiveComparer());
            //            Print(o7);
            //            #endregion
            //            #region Ordering 8
            //            var o8 = Enumerable.Reverse(digits.Where(d => d[1] == 'i'));
            //            Print(o8);
            //            #endregion
            //            #region Transformation 1
            //            var t1 = products.Select(p => p.ProductName);
            //            Print(t1);
            //            #endregion
            //            #region Transformation 2
            //            string[] tWords = { "aPPLE", "BlUeBeRrY", "cHeRry" };
            //            var t2 = tWords.Select(w => new { Upper = w.ToUpper(), Lower = w.ToLower() });
            //            Print(t2);
            //            #endregion
            //            #region Transformation 3
            //            var t3 = products.Select(p => new { p.ProductName, p.Category, Price = p.UnitPrice });
            //            Print(t3);
            //            #endregion
            //            #region Transformation 4
            //            var t4 = aNums.Select((n, i) => new { Number = n, InPlace = n == i });
            //            Console.WriteLine("Number: In-place?");
            //            foreach (var x in t4)
            //                Console.WriteLine($"{x.Number}: {x.InPlace}");
            //            #endregion
            //            #region Transformation 5
            //            int[] numbersA = { 0, 2, 4, 5, 6, 8, 9 };
            //            int[] numbersB = { 1, 3, 5, 7, 8 };
            //            var t5 = from a in numbersA
            //                     from b in numbersB
            //                     where a < b
            //                     select new { a, b };
            //            Console.WriteLine("Pairs where a < b:");
            //            foreach (var x in t5)
            //                Console.WriteLine($"{x.a} is less than {x.b}");
            //            #endregion
            //            #region Partitioning 3
            //            var p3 = aNums.TakeWhile((n, i) => n >= i);
            //            Print(p3);
            //            #endregion
            //            #region Partitioning 4
            //            var p4 = aNums.SkipWhile(n => n % 3 != 0);
            //            Print(p4);
            //            #endregion
            //            #region Partitioning 5
            //            var p5 = aNums.SkipWhile((n, i) => n >= i);
            //            Print(p5);
            //            #endregion
            //            #region Quantifiers 2
            //            var q2 = products.GroupBy(p => p.Category).Where(g => g.Any(p => p.UnitsInStock == 0));
            //            foreach (var g in q2)
            //            {
            //                Console.WriteLine(g.Key);
            //                Print(g);
            //            }
            //            #endregion
            //            #region Quantifiers 3
            //            var q3 = products.GroupBy(p => p.Category).Where(g => g.All(p => p.UnitsInStock > 0));
            //            foreach (var g in q3)
            //            {
            //                Console.WriteLine(g.Key);
            //                Print(g);
            //            }
            //            #endregion
                }
              }
        }